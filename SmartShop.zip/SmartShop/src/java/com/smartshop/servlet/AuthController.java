package com.smartshop.servlet;

import com.smartshop.dao.UserDAO;
import com.smartshop.model.User;
import com.smartshop.util.EmailUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public class AuthController extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String p = req.getServletPath();
        switch (p) {
            case "/login" -> showLogin(req, resp);
            case "/logout" -> doLogout(req, resp);
            case "/register" -> req.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(req, resp);
            case "/forgot" -> req.getRequestDispatcher("/WEB-INF/views/auth/forgot.jsp").forward(req, resp);
            case "/reset" -> req.getRequestDispatcher("/WEB-INF/views/auth/reset.jsp").forward(req, resp);
            case "/account" -> showAccount(req, resp);                // FIX: nạp user vào request
            case "/account/password" -> requireLoginThen(req, resp, "/WEB-INF/views/account/password.jsp");
            default -> resp.sendError(404);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String p = req.getServletPath();
        switch (p) {
            case "/login" -> doLogin(req, resp);
            case "/register" -> doRegister(req, resp);
            case "/forgot" -> doForgot(req, resp);
            case "/reset" -> doReset(req, resp);
            case "/account" -> doUpdateProfile(req, resp);
            case "/account/password" -> doChangePassword(req, resp);
            default -> resp.sendError(404);
        }
    }

    private void showLogin(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(req, resp);
    }

    private void showAccount(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer uid = (Integer) req.getSession().getAttribute("uid");
        if (uid == null) { req.getSession().setAttribute("redirectAfterLogin", req.getRequestURI()); resp.sendRedirect(req.getContextPath()+"/login"); return; }
        User u = userDAO.findById(uid);
        if (u == null) { resp.sendRedirect(req.getContextPath()+"/login"); return; }
        req.setAttribute("user", u);                                   // đặt bean cho JSP
        req.getRequestDispatcher("/WEB-INF/views/account/profile.jsp").forward(req, resp);
    }

    private void doLogin(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        User u = userDAO.findByUsername(username);
        if (u == null || !userDAO.verifyPassword(u, password)) {
            req.setAttribute("error", "Invalid credentials");
            showLogin(req, resp); return;
        }
        if ("LOCKED".equalsIgnoreCase(u.getStatus())) {
            req.setAttribute("error", "Account locked");
            showLogin(req, resp); return;
        }
        HttpSession s = req.getSession(true);
        s.setAttribute("uid", u.getId());
        s.setAttribute("username", u.getUsername());
        List<String> roles = userDAO.rolesOf(u.getId());
        s.setAttribute("roles", roles);
        s.setAttribute("isAdmin", roles != null && roles.contains("ADMIN"));

        String pid=(String)s.getAttribute("pendingAddPid"); String qty=(String)s.getAttribute("pendingAddQty");
        s.removeAttribute("pendingAddPid"); s.removeAttribute("pendingAddQty");
        String redirect=(String)s.getAttribute("redirectAfterLogin"); s.removeAttribute("redirectAfterLogin");
        if (pid!=null) { resp.sendRedirect(req.getContextPath()+"/cart/add?pid="+pid+"&qty="+(qty==null?"1":qty)); return; }
        if (redirect!=null) { resp.sendRedirect(redirect); return; }
        resp.sendRedirect(req.getContextPath()+"/home");
    }

    private void doLogout(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession s = req.getSession(false);
        if (s!=null) s.invalidate();
        resp.sendRedirect(req.getContextPath()+"/login");
    }

    private void doRegister(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        String email=req.getParameter("email");
        String full=req.getParameter("full_name");
        String phone=req.getParameter("phone");

        if (username==null || username.isBlank() || password==null || password.isBlank()) {
            req.setAttribute("error","Thiếu username hoặc password"); req.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(req, resp); return;
        }
        if (userDAO.usernameExists(username)) {
            req.setAttribute("error","Username đã tồn tại"); req.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(req, resp); return;
        }
        String err = userDAO.createWithError(buildUser(username, email, phone, full), password);
        if (err != null) {
            req.setAttribute("error", err); req.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath()+"/login");
        }
    }

    private void doUpdateProfile(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        Integer uid = (Integer) req.getSession().getAttribute("uid");
        if (uid == null) { resp.sendRedirect(req.getContextPath()+"/login"); return; }
        User auth = userDAO.findById(uid);
        if (auth == null) { resp.sendRedirect(req.getContextPath()+"/login"); return; }

        auth.setEmail(req.getParameter("email"));
        auth.setPhone(req.getParameter("phone"));
        auth.setFullName(req.getParameter("full_name"));
        boolean ok = userDAO.updateProfile(auth);
        req.setAttribute("msg", ok ? "Cập nhật thành công" : "Cập nhật thất bại");
        req.setAttribute("user", auth);
        req.getRequestDispatcher("/WEB-INF/views/account/profile.jsp").forward(req, resp);
    }

    private void doChangePassword(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        Integer uid = (Integer) req.getSession().getAttribute("uid");
        if (uid == null) { resp.sendRedirect(req.getContextPath()+"/login"); return; }
        User auth = userDAO.findById(uid);
        if (auth == null) { resp.sendRedirect(req.getContextPath()+"/login"); return; }

        String oldPass = req.getParameter("old_password");
        String newPass = req.getParameter("new_password");
        if (oldPass == null || !userDAO.verifyPassword(auth, oldPass)) {
            req.setAttribute("error","Mật khẩu cũ không đúng");
        } else if (userDAO.changePassword(auth.getId(), newPass)) {
            req.setAttribute("msg","Đổi mật khẩu thành công");
        } else {
            req.setAttribute("error","Đổi mật khẩu thất bại");
        }
        req.getRequestDispatcher("/WEB-INF/views/account/password.jsp").forward(req, resp);
    }

    private void doForgot(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        String email = req.getParameter("email");
        User u = userDAO.findByEmail(email);
        if (u == null) {
            req.setAttribute("info","Nếu email tồn tại, bạn sẽ nhận được hướng dẫn đặt lại mật khẩu.");
            req.getRequestDispatcher("/WEB-INF/views/auth/forgot.jsp").forward(req, resp);
            return;
        }
        String token = UUID.randomUUID().toString();
        String code = String.format("%06d", (int)(Math.random()*1000000));
        LocalDateTime exp = LocalDateTime.now().plusMinutes(15);
        userDAO.saveResetChallenge(u.getId(), token, code, exp);

        String link = req.getRequestURL().toString().replace("/forgot","/reset")+"?token="+token;
        EmailUtil.send(u.getEmail(), "SmartShop - Reset password",
                "<p>Mã xác nhận: <b>"+code+"</b></p><p>Liên kết: <a href=\""+link+"\">"+link+"</a></p><p>Hết hạn sau 15 phút.</p>");

        req.setAttribute("info","Đã gửi mã xác nhận qua email.");
        req.getRequestDispatcher("/WEB-INF/views/auth/forgot.jsp").forward(req, resp);
    }

    private void doReset(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        String token = req.getParameter("token");
        String code  = req.getParameter("code");
        String step  = req.getParameter("step");

        if (step == null) {
            if (token != null && !token.isBlank()) {
                User u = userDAO.findByResetToken(token);
                if (u != null) req.getSession().setAttribute("resetUserId", u.getId());
            }
            req.getRequestDispatcher("/WEB-INF/views/auth/reset.jsp").forward(req, resp);
            return;
        }

        HttpSession ses = req.getSession();
        if ("verify".equals(step)) {
            User u = (code!=null && code.matches("\\d{6}")) ? userDAO.findByResetCode(code) : null;
            if (u != null) {
                ses.setAttribute("resetUserId", u.getId());
                req.setAttribute("stage","setnew");
                req.getRequestDispatcher("/WEB-INF/views/auth/reset.jsp").forward(req, resp);
            } else {
                req.setAttribute("error","Mã không hợp lệ hoặc đã hết hạn");
                req.getRequestDispatcher("/WEB-INF/views/auth/reset.jsp").forward(req, resp);
            }
        } else if ("setnew".equals(step)) {
            Integer uid = (Integer) ses.getAttribute("resetUserId");
            if (uid == null) { resp.sendRedirect(req.getContextPath()+"/forgot"); return; }
            String newPass = req.getParameter("new_password");
            User u = userDAO.findById(uid);
            if (u == null) { resp.sendRedirect(req.getContextPath()+"/forgot"); return; }
            if (userDAO.changePassword(u.getId(), newPass)) {
                userDAO.clearResetToken(u.getId());
                ses.removeAttribute("resetUserId");
                resp.sendRedirect(req.getContextPath()+"/login");
            } else {
                req.setAttribute("msg","Đổi mật khẩu thất bại");
                req.getRequestDispatcher("/WEB-INF/views/auth/reset.jsp").forward(req, resp);
            }
        }
    }

    private void requireLoginThen(HttpServletRequest req, HttpServletResponse resp, String view) throws IOException, ServletException {
        if (req.getSession().getAttribute("uid") == null) {
            req.getSession().setAttribute("redirectAfterLogin", req.getRequestURI());
            resp.sendRedirect(req.getContextPath()+"/login"); return;
        }
        req.getRequestDispatcher(view).forward(req, resp);
    }

    private static User buildUser(String username, String email, String phone, String full) {
        User u = new User(); u.setUsername(username); u.setEmail(email); u.setPhone(phone); u.setFullName(full); return u;
    }
}
