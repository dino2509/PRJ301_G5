package com.smartshop.servlet.auth;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;

@WebServlet(urlPatterns = "/forgot")
public class ForgotServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/auth/forgot.jsp").forward(req, resp);
    }
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Tối giản: chỉ hiển thị thông báo chung
        req.setAttribute("info", "Nếu email tồn tại, bạn sẽ nhận hướng dẫn đặt lại mật khẩu.");
        doGet(req, resp);
    }
}
